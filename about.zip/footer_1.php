   <footer class="eb_h3-footer-area">
                    <div class="eb_h3-footer-top pt-110 pb-80">

                        <div class="container">
                            <div class="row justify-content-between">
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-7">
                                    <div class="eb_h3-footer-widget1 mb-30">
                                        <div class="eb_h3-footer-logo">
                                            <a href="index.html"><img src="assets/img/logo/logo-bg.png" alt=""></a>
                                        </div>
                                        <div class="d-flex justify-content-start">
                                            <ul class="d-flex list-unstyled gap-3 m-0">
                                                <li><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
                                                <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                                                <li><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
                                                <li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
                                            </ul>
                                        </div>


                                    </div>
                                </div>
                                <div class="col-xl-2 col-lg-2 col-sm-5">
                                    <div class="eb_h3-footer-widget mb-30">
                                        <h3 class="eb_h3-footer-widget-title">
                                            Quick Links
                                        </h3>
                                        <ul>

                                            <li><a href="blog.html">Blogs</a></li>
                                            <li><a href="contact.html">Contact Us</a></li>
                                            <li><a href="about.html">About US</a></li>
                                            <li><a href="privacy-policy.html">privacy-policy</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-xl-2 col-lg-2 col-sm-5">
                                    <div class="eb_h3-footer-widget mb-30">
                                        <h3 class="eb_h3-footer-widget-title">Services</h3>
                                        <ul>
                                            <li><a href="price.html">Pricing</a></li>
                                            <li><a href="faq.html">FAQ</a></li>
                                            <li><a href="blog.html">Blogs</a></li>
                                            <li><a href="terms-and-conditions.html"> Terms and conditions</a></li>

                                        </ul>
                                    </div>
                                </div>

                                <div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-7 order-lg-4 order-sm-3">
                                    <div class="eb_h3-footer-widget mb-30">
                                        <h3 class="eb_h3-footer-widget-title">Addres </h3>


                                    </div>
                                    <div class="eb_h3-footer-address">
                                        <a href="#"><i class="fa-solid fa-location-dot"></i>London SO587 2kh <br>
                                            GV25+G6 United Kingdom</a>
                                        <a href="tel:+222682582368"><i class="fa-solid fa-phone"></i>+222 68 258
                                            2368</a>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="eb_h3-footer-bottom">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 d-flex justify-content-center">
                                    <div class="eb_h3-footer-copyright-text">
                                        <p>©2025 All Rights Reserved by site</p>
                                    </div>
                                </div>
                                <!-- <div class="col-md-6">
                                    <div class="eb_h3-footer-menu">
                                        <ul>
                                            <li><a href="#">Privacy Policy</a></li>
                                            <li><a href="#">Term of Service</a></li>
                                        </ul>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </footer>